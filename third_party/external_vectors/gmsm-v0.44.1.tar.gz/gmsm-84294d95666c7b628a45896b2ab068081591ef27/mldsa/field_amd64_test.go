// Copyright 2026 Sun Yimin. All rights reserved.
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file.

//go:build amd64 && !purego

package mldsa

import "testing"

func TestInternalNTTAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		r := randomRingElement()

		got := r
		internalNTTAVX2(&got)

		want := r
		internalNTTGeneric(&want)

		if got != want {
			t.Logf("want: %v", want)
			t.Logf("got:  %v", got)
			t.Fatalf("internalNTTAVX2 mismatch on iteration %d", i)
		}
	}
}

func TestInternalInverseNTTAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		r := randomRingElement()

		// Convert to NTT representation
		nttForm := r
		internalNTTGeneric(&nttForm)

		// Test AVX2 version
		got := nttElement(nttForm)
		internalInverseNTTAVX2(&got)

		// Test generic version
		want := nttElement(nttForm)
		internalInverseNTTGeneric(&want)

		if got != want {
			t.Logf("want: %v", want)
			t.Logf("got:  %v", got)
			t.Fatalf("internalInverseNTTAVX2 mismatch on iteration %d", i)
		}
	}
}

func TestNTTMulAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		left := ntt(randomRingElement())
		right := ntt(randomRingElement())

		var got nttElement
		nttMulAVX2(&left, &right, &got)

		var want nttElement
		nttMulGeneric(&want, &left, &right)
		if got != want {
			t.Fatalf("nttMulAVX2 mismatch on iteration %d", i)
		}
	}
}

func TestNTTMul(t *testing.T) {
	for i := 0; i < 16; i++ {
		left := ntt(randomRingElement())
		right := ntt(randomRingElement())

		var got nttElement
		nttMul(&got, &left, &right)

		var want nttElement
		nttMulGeneric(&want, &left, &right)
		if got != want {
			t.Fatalf("nttMulInto mismatch on iteration %d", i)
		}
	}
}

func TestPolyAddAssignAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		left := randomRingElement()
		right := randomRingElement()

		got := left
		polyAddAssignAVX2(&got[0], &right[0])

		want := left
		polyAddGeneric(&want, &right)
		if got != want {
			t.Fatalf("polyAddAssignAVX2 mismatch on iteration %d", i)
		}
	}
}

func TestPolySubAssignAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		left := ntt(randomRingElement())
		right := ntt(randomRingElement())

		got := left
		polySubAssignAVX2(&got[0], &right[0])

		want := left
		polySubGeneric(&want, &right)
		if got != want {
			t.Fatalf("polySubAssignAVX2 mismatch on iteration %d", i)
		}
	}
}

func TestPolyAddAssign(t *testing.T) {
	for i := 0; i < 16; i++ {
		left := randomRingElement()
		right := randomRingElement()

		got := left
		polyAddAssign(&got, &right)

		want := left
		polyAddGeneric(&want, &right)
		if got != want {
			t.Fatalf("polyAddAssign mismatch on iteration %d", i)
		}
	}
}

func TestPolySubAssign(t *testing.T) {
	for i := 0; i < 16; i++ {
		left := ntt(randomRingElement())
		right := ntt(randomRingElement())

		got := left
		polySubAssign(&got, &right)

		want := left
		polySubGeneric(&want, &right)
		if got != want {
			t.Fatalf("polySubAssign mismatch on iteration %d", i)
		}
	}
}

func TestPolyInfinityNormAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		r := randomRingElement()
		got := int(polyInfinityNormAVX2(&r[0]))
		want := polyInfinityNormGeneric(&r, 0)
		if got != want {
			t.Fatalf("polyInfinityNormAVX2 mismatch on iteration %d: got %d want %d", i, got, want)
		}
	}
}

func TestPolyInfinityNormSignedAVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		var a [n]int32
		r := randomRingElement()
		for j := range a {
			a[j] = int32(r[j]) - int32(qMinus1Div2)
		}
		got := int(polyInfinityNormSignedAVX2(&a[0]))
		want := polyInfinityNormSignedGeneric(&a, 0)
		if got != want {
			t.Fatalf("polyInfinityNormSignedAVX2 mismatch on iteration %d: got %d want %d", i, got, want)
		}
	}
}

func TestDecomposeSubToR0Gamma32AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		w := randomRingElement()
		cs2 := randomRingElement()

		var got [n]int32
		decomposeSubToR0Gamma32AVX2(&w[0], &cs2[0], &got[0])

		var want [n]int32
		decomposeSubToR0Generic(&want, &w, &cs2, gamma2QMinus1Div32)

		if got != want {
			t.Fatalf("decomposeSubToR0Gamma32AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestDecomposeSubToR0Gamma88AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		w := randomRingElement()
		cs2 := randomRingElement()

		var got [n]int32
		decomposeSubToR0Gamma88AVX2(&w[0], &cs2[0], &got[0])

		var want [n]int32
		decomposeSubToR0Generic(&want, &w, &cs2, gamma2QMinus1Div88)

		if got != want {
			t.Fatalf("decomposeSubToR0Gamma88AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestDecomposeSubToR0(t *testing.T) {
	for i := 0; i < 16; i++ {
		w := randomRingElement()
		cs2 := randomRingElement()

		for _, gamma2 := range []uint32{gamma2QMinus1Div32, gamma2QMinus1Div88} {
			var got [n]int32
			decomposeSubToR0(&got, &w, &cs2, gamma2)

			var want [n]int32
			decomposeSubToR0Generic(&want, &w, &cs2, gamma2)

			if got != want {
				t.Fatalf("decomposeSubToR0 mismatch on iteration %d gamma2=%d", i, gamma2)
			}
		}
	}
}

func TestUseHintPolyGamma32AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		h := randomRingElement()
		r := randomRingElement()
		for j := range h {
			h[j] &= 1
		}

		var got ringElement
		useHintPolyGamma32AVX2(&h[0], &r[0], &got[0])

		var want ringElement
		useHintPolyGeneric(&want, &h, &r, gamma2QMinus1Div32)

		if got != want {
			t.Fatalf("useHintPolyGamma32AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestUseHintPolyGamma88AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 16; i++ {
		h := randomRingElement()
		r := randomRingElement()
		for j := range h {
			h[j] &= 1
		}

		var got ringElement
		useHintPolyGamma88AVX2(&h[0], &r[0], &got[0])

		var want ringElement
		useHintPolyGeneric(&want, &h, &r, gamma2QMinus1Div88)

		if got != want {
			t.Fatalf("useHintPolyGamma88AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestUseHintPoly(t *testing.T) {
	for i := 0; i < 16; i++ {
		h := randomRingElement()
		r := randomRingElement()
		for j := range h {
			h[j] &= 1
		}

		for _, gamma2 := range []uint32{gamma2QMinus1Div32, gamma2QMinus1Div88} {
			var got ringElement
			useHintPoly(&got, &h, &r, gamma2)

			var want ringElement
			useHintPolyGeneric(&want, &h, &r, gamma2)

			if got != want {
				t.Fatalf("useHintPoly mismatch on iteration %d gamma2=%d", i, gamma2)
			}
		}
	}
}

func TestMakeHintPolyGamma32AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 64; i++ {
		ct0 := randomRingElement()
		cs2 := randomRingElement()
		w := randomRingElement()

		var got ringElement
		makeHintPolyGamma32AVX2(&ct0[0], &cs2[0], &w[0], &got[0])

		var want ringElement
		for j := range n {
			want[j] = makeHint(ct0[j], cs2[j], w[j], gamma2QMinus1Div32)
		}

		if got != want {
			t.Fatalf("makeHintPolyGamma32AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestMakeHintPolyGamma88AVX2(t *testing.T) {
	if !useAVX2 {
		t.Skip("AVX2 is not available")
	}

	for i := 0; i < 64; i++ {
		ct0 := randomRingElement()
		cs2 := randomRingElement()
		w := randomRingElement()

		var got ringElement
		makeHintPolyGamma88AVX2(&ct0[0], &cs2[0], &w[0], &got[0])

		var want ringElement
		for j := range n {
			want[j] = makeHint(ct0[j], cs2[j], w[j], gamma2QMinus1Div88)
		}

		if got != want {
			t.Fatalf("makeHintPolyGamma88AVX2 mismatch on iteration %d", i)
		}
	}
}

func TestVectorMakeHintAMD64(t *testing.T) {
	for _, gamma2 := range []uint32{gamma2QMinus1Div32, gamma2QMinus1Div88} {
		for i := 0; i < 16; i++ {
			k := 4
			ct0 := make([]ringElement, k)
			cs2 := make([]ringElement, k)
			w := make([]ringElement, k)
			for j := range k {
				ct0[j] = randomRingElement()
				cs2[j] = randomRingElement()
				w[j] = randomRingElement()
			}

			got := make([]ringElement, k)
			vectorMakeHint(ct0, cs2, w, got, gamma2)

			want := make([]ringElement, k)
			vectorMakeHintGeneric(ct0, cs2, w, want, gamma2)

			for j := range k {
				if got[j] != want[j] {
					t.Fatalf("vectorMakeHint mismatch on i=%d j=%d gamma2=%d", i, j, gamma2)
				}
			}
		}
	}
}
